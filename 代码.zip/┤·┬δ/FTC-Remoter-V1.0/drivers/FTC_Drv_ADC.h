#ifndef __FTC_DRV_ADC_H
#define	__FTC_DRV_ADC_H

#include "board.h"

void ADC1_Init(void);

extern __IO uint16_t ADC_ConvertedValue[7];

#endif /* __ADC_H */


