#ifndef __FTC_DRV_ADC_H
#define	__FTC_DRV_ADC_H

#include "stm32f10x.h"

void FTC_ADC_Init(void);

void FTC_ADC_Battery(void);

extern float V_Battery;

#endif





